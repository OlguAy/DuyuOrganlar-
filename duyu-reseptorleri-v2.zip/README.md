# Duyu Reseptörleri — V2

11. sınıf biyoloji için etkileşimli React + TypeScript uygulaması.

## Çalıştırma

```bash
npm install
npm run dev
```

## V2 değişiklikleri

- Öğrenci adı / sınıf girişi kaldırıldı; uygulama doğrudan ana menüden açılır.
- Sağ üstteki küçük dişli ile içerik düzenleme modu açılır.
- Düzenleme PIN'i: `12911`
- Sağ bilgi paneli bulunduğu ekran üzerinde düzenlenebilir.
- Başlık, üst başlık, açıklama ve bilgi maddeleri değiştirilebilir.
- Değişiklikler bu sürümde `localStorage` içinde kalıcı tutulur.
- Her aşama için "Varsayılana dön" desteği vardır.
- Göz akışı artık 4 aşamadır:
  1. Göz
  2. Fotoreseptör
  3. Nöron
  4. Kimyasal İletim / Sinaps
- Kimyasal iletim için nörotransmitterlerin sinaptik aralıkta hareketini gösteren yeni animasyon sahnesi eklendi.
- Storage katmanı `contentRepository` üzerinden soyutlandı; sonraki aşamada Supabase/API ile değiştirilebilir.

## İçerik yapısı

Varsayılan içerikler `src/modules/eye/eye.module.ts` içinde bulunur.
Kullanıcı tarafından yapılan düzenlemeler `src/core/content/contentRepository.ts` üzerinden saklanır.
